import api from './client';

const bookingsApi = {
  getAll:          (params = {}) => api.get('/bookings', { params }),
  getStats:        ()            => api.get('/bookings/stats'),
  getById:         (id)          => api.get(`/bookings/${id}`),
  create:          (data)        => api.post('/bookings', data),
  update:          (id, data)    => api.put(`/bookings/${id}`, data),
  getGroupMembers: (id)          => api.get(`/bookings/${id}/members`),
  addGroupMember:  (id, data)    => api.post(`/bookings/${id}/members`, data),
  removeMember:    (bookingId, customerID) => api.delete(`/bookings/${bookingId}/members/${customerID}`),
  getDestinations: () => api.get('/destinations'),
  getClassTypes:   () => api.get('/class-types'),
  getBookingFees:  () => api.get('/booking-fees'),
  getProducts:     () => api.get('/products'),
  getCustomers:    (params = {}) => api.get('/customers', { params }),
};

export default bookingsApi;
