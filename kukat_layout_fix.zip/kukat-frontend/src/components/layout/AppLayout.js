import React from 'react';
import { Box } from '@mui/material';
import Sidebar from './Sidebar';
import TopBar from './TopBar';
import { KUKAT } from '../../styles/theme';

export default function AppLayout({ children, title, subtitle }) {
  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', background: KUKAT.surface }}>

      {/* Sidebar — fixed width, never shrinks */}
      <Sidebar />

      {/* Main content — takes all remaining space */}
      <Box sx={{
        flex: '1 1 0%',
        minWidth: 0,
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
      }}>
        <TopBar title={title} subtitle={subtitle} />
        <Box sx={{
          flex: 1,
          p: { xs: 2, sm: 3 },
          overflowY: 'auto',
          overflowX: 'hidden',
        }}>
          {children}
        </Box>
      </Box>
    </Box>
  );
}
